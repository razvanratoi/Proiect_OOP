package main;
import view.LoginView;
import view.PageView;

import view.PageView;

import java.sql.*;

public class Main {
    static public  void main(String[] args){
        LoginView loginView = new LoginView();
        loginView.setVisible(true);
        }
}
